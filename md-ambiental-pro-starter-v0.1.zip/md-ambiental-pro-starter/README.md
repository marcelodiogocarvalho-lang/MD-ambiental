# MD Ambiental Pro — Starter v0.1

Base inicial Next.js 15 + TypeScript + Tailwind CSS 4 + Supabase Auth.

## Instalação

1. Requer Node.js 20+.
2. `npm install`
3. Copie `.env.example` para `.env.local` e configure URL e chave pública (anon/publishable) do projeto Supabase de desenvolvimento.
4. `npm run dev`
5. Abra http://localhost:3000

## Segurança e limites

- Nunca inclua a chave `service_role` no frontend ou no GitHub.
- A rota `/dashboard` faz uma checagem **no cliente**; isto NÃO é uma proteção suficiente para dados sensíveis ou APIs. A autorização real deverá ser aplicada com RLS, middleware/servidor e verificação de organização e papel.
- MFA obrigatório para administradores, isolamento multi-tenant, recuperação de senha, cadastros e pagamentos **ainda não estão implementados**.
- Não publique como SaaS comercial até concluir esses controles, testes, LGPD e checkout.
- A Migração SQL 002 não foi executada por este pacote.

## Próximos passos

Auditar esquema Supabase; implementar autenticação server-side, MFA, RLS testado, organização, clientes, empreendimentos, licenças, condicionantes, documentos, planos e cobrança.
